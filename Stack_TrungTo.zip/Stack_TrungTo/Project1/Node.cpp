#include "Node.h"


Node::Node(void)
{
}


Node::~Node(void)
{
}
