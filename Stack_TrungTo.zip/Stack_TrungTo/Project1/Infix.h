#pragma once
#include "Stack.h"
#include <sstream>
#include <vector>

class Infix
{
public:
	Infix();
	~Infix();
	string* ParseInput(string Input, int& iLength);
	int UT(string x);
	int HT(string x);
	string CalcValue(string b, string x, string a);
	float CalcValue(vector<string> M);
};